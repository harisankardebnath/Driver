# Linux Kernel Driver — Android GKI source workspace

This project fetches three separate full Android Common Kernel (ACK/GKI)
source checkouts and integrates a small diagnostic character-device module
into each source tree.

## Included source branches

| Linux version | Android kernel manifest branch | Build system |
|---|---|---|
| 5.10 | `common-android13-5.10` | Kleaf / Bazel |
| 5.15 | `common-android14-5.15` | Kleaf / Bazel |
| 6.1 | `common-android14-6.1` | Kleaf / Bazel |

The full upstream source is not copied into this ZIP because each checkout is
large and is maintained by Google. `scripts/fetch-gki.sh` downloads all three
complete manifest workspaces into `sources/`.

## Project layout

```text
Linux-Kernel-Driver-GKI/
├── .github/workflows/build-gki.yml
├── driver/
│   ├── linux_kernel_driver.c
│   ├── Kconfig
│   ├── Makefile
│   └── driver_uapi.h
├── scripts/
│   ├── fetch-gki.sh
│   ├── integrate-driver.sh
│   ├── build-gki.sh
│   └── test-device.sh
├── sources/
│   ├── 5.10/   # fetched full repo workspace
│   ├── 5.15/   # fetched full repo workspace
│   └── 6.1/    # fetched full repo workspace
└── artifacts/
```

## What the diagnostic driver does

The module creates `/dev/linux_kernel_driver` and supports:
- read/write of its own fixed 4 KiB test buffer;
- `LKD_IOC_CLEAR` to clear that buffer;
- `LKD_IOC_SIZE` to report the current buffer length.

It does not access another process's address space, physical memory, kernel
memory, or game memory. It has no process-hiding or anti-cheat functionality.
It is not a backend for the memory operations in the previously supplied
cheat header.

## Requirements

Use a Linux x86_64 build host (or a suitably provisioned self-hosted GitHub
Actions runner) with several tens of GB of free disk space and adequate RAM.
Full source sync and Bazel builds are large. GitHub-hosted runner resource
limits may cause out-of-memory or disk-space failures for some branches.

Install Google's `repo` tool and the usual Android kernel build dependencies.
The workflow installs these on its runner.

## Fetch all complete source trees

```bash
./scripts/fetch-gki.sh
```

Fetch only one:

```bash
./scripts/fetch-gki.sh 6.1
```

The script uses Google's kernel manifest:

`https://android.googlesource.com/kernel/manifest`

## Build one version locally

```bash
./scripts/build-gki.sh 5.10
./scripts/build-gki.sh 5.15
./scripts/build-gki.sh 6.1
```

The script integrates the driver into `common/drivers/misc` and runs the
official AArch64 Kleaf distribution target:

```bash
tools/bazel run //common:kernel_aarch64_dist -- --destdir=/path/to/dist
```

The build output is placed under `artifacts/<version>/`.

## GitHub Actions

1. Create a GitHub repository named `linux-kernel-driver`.
2. Upload the contents of this project ZIP to the repository root.
3. Open **Actions → Build Android GKI + Diagnostic Driver → Run workflow**.
4. Choose `5.10,5.15,6.1` or a subset.
5. Download the corresponding version artifacts after each job completes.

Each matrix job syncs the full Google manifest checkout, integrates the module,
and builds the ARM64 GKI distribution.

## Important compatibility notes

- A generic GKI build is not a drop-in kernel for every phone.
- The GKI build does not include every OEM/vendor driver.
- A `.ko` built for one exact kernel build/KMI is not automatically compatible
  with another kernel that happens to have the same Linux version.
- Vendor modules, symbol lists, configuration, signing policy and KMI must
  match the target device.
- The Moto G64's `5.10.218` vendor kernel is not identical to the generic
  `common-android13-5.10` branch. Use the Motorola device kernel source and
  matching build configuration for a device module intended for that phone.
- Do not flash the generic GKI output to a phone unless that exact device,
  vendor module set, boot image format and AVB setup are supported and tested.
  This project does not flash anything.

## References

- Android kernel source/build guide:
  https://source.android.com/docs/setup/build/building-kernels
- Android kernel branches and build systems:
  https://source.android.com/docs/setup/reference/bazel-support
- Android Common Kernel manifest:
  https://android.googlesource.com/kernel/manifest
